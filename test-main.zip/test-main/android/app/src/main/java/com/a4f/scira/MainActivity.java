package com.a4f.scira;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
