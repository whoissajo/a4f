export const MAX_IMAGES = 4;
export const MAX_INPUT_CHARS = 10000;