import { useIsMobile } from "@/hooks/use-mobile";

export default useIsMobile;
